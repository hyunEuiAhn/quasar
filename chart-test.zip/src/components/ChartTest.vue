<template>
    <div class="flex">
        <div
            :class="`testBox${idx}`"
            v-for="(val, idx) in Array(4000)"
            :key="idx"
            :style="{ width: '10px', height: '10px', backgroundColor: `rgb(20,${Math.floor(Math.random() * 100) + 150},20)` }"
        ></div>
    </div>
</template>
<script>
import {} from "vue";
export default {
    setup() {},
};
</script>
